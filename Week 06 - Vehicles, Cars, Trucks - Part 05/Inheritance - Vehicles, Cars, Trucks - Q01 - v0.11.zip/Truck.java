public class Truck extends Vehicle
{
	private double loadingCapacity; // Tons

	public Truck ()
	{
		super();
		loadingCapacity = 0;
	}

	public Truck (String model, String buildDate,
	            double fuelEcon, double loadingCapacity)
	{
		super (model, buildDate, fuelEcon);
		this.loadingCapacity = loadingCapacity;
	}

	public Truck (String model, String buildDate,
	            double fuelEcon, Manufacturer manufacturer, double loadingCapacity)
	{
		super (model, buildDate, fuelEcon, manufacturer);
		this.loadingCapacity = loadingCapacity;
	}

	public double getLoadingCapacity ()
	{
		return loadingCapacity;
	}

	public void setLoadingCapacity (double loadingCapacity)
	{
		this.loadingCapacity = loadingCapacity;
	}

	@Override
	public String toString()
	{
		return 	super.toString() + " " +
		       	String.format ("%8.2f", loadingCapacity) + "T";
	}

}