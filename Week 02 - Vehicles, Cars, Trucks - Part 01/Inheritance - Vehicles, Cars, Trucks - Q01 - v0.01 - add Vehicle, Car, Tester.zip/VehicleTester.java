public class VehicleTester
{
	public static void main (String[] args)
	{
		Vehicle v1 = new Vehicle ();
		System.out.println (v1);

		Vehicle v2 = new Vehicle ("Porsche", "2020-Dec", 3);
		System.out.println (v2);

		Car c1 = new Car ("Lambo", "Dec-2020", 2, 2);
		System.out.println (c1);

	}
}