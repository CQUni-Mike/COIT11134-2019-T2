# COIT11134-Week-02-Vehicles-Cars-Trucks
COIT11134 - Week 02 - Vehicles-Cars-Trucks

## Inheritance Tutorial Question:  The Basics

There are 5 questions below and each consists of multiple parts.

* Question 1 solution:
https://github.com/CQUni-Mike/COIT11134-Week-02-Vehicles-Cars-Trucks

* Question 2 solution:
https://github.com/CQUni-Mike/COIT11134-Week-03-Vehicles-Cars-Trucks

* Question 3 solution:
https://github.com/CQUni-Mike/COIT11134-Week-04-Vehicles-Cars-Trucks

* Question 4 solution:
https://github.com/CQUni-Mike/COIT11134-Week-05-Vehicles-Cars-Trucks

* Question 5 solution:
TBA


## Question 1: A hierarchy of 3 Classes plus a Tester Class

This question has multiple parts:

1A.	Create a **Vehicle** class with the following members:
* A field for the vehicle model description (a string).
* A field for the year and month that the vehicle was built (a string).
* A field for the fuel economy per litre (a double).
* A Default Constructor
* A Parameterised Constructor
* Appropriate accessors and mutators for all class fields.
* A toString() method that displays the necessary vehicle detail.

1B.	Create a **VehicleTester** class with a main() that creates at least 2 Vehicles and executes all of the methods in the **Vehicle** class to ensure everything works, and that you understand everything.  :)

1C.	Implement the **Car** class that extends the **Vehicle** class, and includes the following members:
* A field for the maximum number of passenger (an int).
* A Default Constructor
* A Parameterised Constructor
* Appropriate accessors and mutators for all class field(s).
* A toString() method that overrides the toString() method in the superclass and displays relevant information on a Car object.

1D.	Add code to the **VehicleTester** class to create at least 2 Cars and executes all of the methods in the **Car** class to ensure everything works, and that you understand everything.  :)  i.e. Your tester class should create and invoke methods for at least 2 Vehicles and 2 Cars.


1E.	Implement the **Truck** class that extends the **Vehicle** class, and includes the following members:
* A field for the loading capacity in tonnage (a double).
* A Default Constructor
* A Parameterised Constructor
* Appropriate accessors and mutators for all class field(s).
* A toString() method that overrides the toString() method in the superclass and displays relevant information on a Car object.

1F.	Add code to the **VehicleTester** class to create at least 2 Trucks and executes all of the methods in the **Truck** class to ensure everything works, and that you understand everything.  :)  i.e. Your tester class should create and invoke methods for at least 2 Vehicles and 2 Cars and 2 Trucks.

1G.	Homework: to have fun and explore and build your understanding, add more classes to the Vehicle class hierarchy:
* Motorbike: engine capacity, on-road or off road, ...
* Car subclass/child -> Electric Car, range, etc
* Aircraft
* Boats
* etc, whatever you like.  The key is to explore and build your understanding.



## Question 2: Arrays and ArrayLists

2A. 	Add code to the **VehicleTester** class to create an **Array** of Vehicles.  Add existing Vehicles and Cars and Trucks that you have already declared to the Array.  Also declare new Vehicles and Cars and Trucks and store these directly into the array.  Have at least 4 Vehicles, 4 Cars, and 4 Trucks in your Array.  i.e. Have at least 12 objects in your array.

2B.	Add code to the **VehicleTester** class to loop through all Vehicles in the array and display them to the screen (call each object�s toString() method).  Use a *counter controlled for loop* and then do the same thing again using a *for each loop* (aka an *enhanced for loop*).

2C. 	Add code to the **VehicleTester** class to loop through all Vehicles in the array and calculate and display the total loading (carrying) capacity of all Trucks in the array.
**Hint:** use *instanceof* to determine which Vehicles are Trucks, and use *typecasting* to invoke the getLoadingCapacity() method.

2D.	Use a loop to count the number of Cars and calculate the total passengers of all Cars in the array, and display the *average passengers per vehicle* to the screen.
**Hint:** use *instanceof* to determine which Vehicles are Cars, and use *typecasting* to invoke the getNumPassengers() method.

2E.	Change over from using an Array to an ArrayList.


## Question 3: Slap a GUI on it

3A.	Add a prompt label and textfield for vehicle make,
	a textarea, scrollpane, and a button called "Add".
"Add" button should trim leading and trailing white space from inputs and
validates user inputs - Hint: trim() - and:
* If Make is blank, display an error dialog,
sets textfield background colour to red, and
sets cursor focus to textfield.
* Otherwise, if user inputs are valid, create a vehicle,
add it to ArrayList, and
displays latest vehicle in textarea.

3B.	Add prompt labels and textfields for build date and fuel economy.
Add validations:
* build date cannot be blank,
* fuel economy must be a double between 5.0 and 10.0 inclusive.
and fit these into the existing validation structure.

**Hint:** You will need to convert the user input from a String to a
double, and you can do this using **Exception Handling** like this:

```
double fuelEcon    = 0;

try
{
	fuelEcon    = Double.parseDouble (fuelEconStr);
}
catch (Exception err)
{
	 fuelEcon    = 0;
}
```


3C.	Add an "Exit" button and exit confirmation dialog that prompts the
	user to confirm the exit if the user clicks the "Exit" button or clicks the
	"X" icon in the top corner of the JFrame.
	Hint: use *addWindowListener* to override the default *windowClosing* method.

3D.	Add a method to clear all user inputs, and call this when
	the application starts up and whenever a Vehicle is added to the array.

3E.	Add a "Display" button to invoke a display() method to
	display all vehicles in the ArrayList
	to the textarea.

3F.	Add a "Test Data" button to add some Vehicles to the ArrayList and invoke
	the display() method.  Generate random values for fuel economy.


## Question 4: More GUI

4A.	Add radiobuttons to enable the user to select the
Vehicle, Car, Truck, .... they want to input.
Hint: don't forget the ButtonGroup.

4B.	Add a prompt label and textfield for each of the fields associated with these
new types of Vehicles and only enable them if the particular type of
Vehicle is selected.
e.g. if Car radiobutton is selected, then number of passengers label and text field
should be enabled, otherwise these gui components should be disabled.
Hint: setEnabled().

4C.	Add validations which apply for each type of Vehicle
when the "Add" button is pressed.
e.g. if Car radiobutton is selected, then number of passengers
must be between 1 and 6 inclusive.

4D.	Add a combobox to enable the user to select a Vehicle in the ArrayList
and a "Delete" button which prompts the user to confirm the deletion and
deletes the selected Vehicle from the ArrayList if the user confirms the deletion.

4E.	Add JTabbedPane and place all of the
* Place all of the "Add" vehicle related functionality / components to it's own tab,
* Place all of the "Delete" related functionality / components to it's own tab,
* Place all of the "Display" related functionality / components to it's own tab,



## Question 5: File I/O, ....
TBA

